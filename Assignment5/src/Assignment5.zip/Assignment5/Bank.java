
import java.awt.Graphics;
import java.util.*;

public class Bank extends Sprite {
	
	Bank(){
		
		super("bank.png");
		setX(300);
		setY(300);
	}
	public void updateImage(Graphics g) {
		super.updateImage(g);
	}

}
